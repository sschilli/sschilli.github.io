#include <iostream>
#include <cstdlib>

int main(int argc, char** argv) {
	std::cout << "Hola mundo!" << std::endl;

	// Loop through all the command line arguments
	// argc is the count of arguments
	// argv is the char* (string) array of arguments
	for (size_t i = 0; i < argc; i++) {
		std::cout << "Command line arg #"
			<< i << " is: "
			<< argv[i]
		       	<< std::endl;
	}

	return EXIT_SUCCESS;
}
