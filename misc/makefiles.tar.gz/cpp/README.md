# Understanding make and Makefiles
This directory shows an example c++ project and how make can be used to build
and manage the project from the command line.

First, read the comments in the example Makefile to understand what targets are
available to you. The comments at the top of the file show the different
invocations of make available from the targets defined.

Then, try running the different make targets and observe their effects on the
working directory/project.

```
# See the state of the working directory
$ ls -1
Makefile
README.md
src

# Invoke the default make target to build the project
$ make
mkdir -p bin
g++  src/main.cpp -c -o bin/main.o
g++ -Wall -MMD -MP -Isrc -std=c++11 bin/main.o -o Greeter 

# See the impact of running that make target
$ ls -1
Greeter
Makefile
README.md
bin
src

# Run the compiled binary (the c++ executable)
$ ./Greeter
Hola mundo!
Command line arg #0 is: ./Greeter

# Invoke the make clean target to remove generated files
$ make clean
rm -rf Greeter  bin/

$ ls -1
Makefile
README.md
src
```

Note that make will output the commands it runs for the specified target. For
instance, our initial invocation of the default target runs three commands: one
`mkdir` and two `g++`.

What if we invoke the default target again, before the `make clean` invocation,
in the session above? Try it on your own machine and see one of the reasons
`make` is so useful!

Then, try adding more files to this project. The provided Makefile should
automatically detect `.cpp` files in the `src/` directory and make will know
when it is necessary to (re)compile those files.

# Understanding Command Line Arguments
Once you understand how the various make targets impact the state of your
project (and working directory), compile the project.

(Hint: you'll likely invoke the default make target as shown above.)

Now, look at the main function defined in `src/main.cpp`.

Note that the function takes parameters `int argc` (count of command line
arguments) and `char** argv` (the command line arguments themselves - as text).

Once you understand the behavior of the main function (specifically the
for-loop), try running the project as follows:

```
$ ./Greeter
Hola mundo!
Command line arg #0 is: ./Greeter

$ ./Greeter A
Hola mundo!
Command line arg #0 is: ./Greeter
Command line arg #1 is: A

$ ./Greeter --language English
Hola mundo!
Command line arg #0 is: ./Greeter
Command line arg #1 is: --language
Command line arg #2 is: English

$ ./Greeter input_filename.txt output_filename.txt
Hola mundo!
Command line arg #0 is: ./Greeter
Command line arg #1 is: input_filename.txt
Command line arg #2 is: output_filename.txt
```

Command line arguments allow a user of a c++ project to pass options or
required information to the project when called from the command line. This is
especially useful when the c++ executable expects to operate on a file: we can
pass the filename as a command line argument rather than hardcoding the
filename in our project. If an input file's name is hardcoded in the project,
then the project must be recompiled to operate on another input. To avoid this,
we could document that our program expects a filename argument and then parse
the `argv` array to set a filename variable accordingly.

A simple approach to parsing command line arguments is to specify that the user
must provide them in an expected order, then iterate over the arguments in
`argv` and use if-else controls to parse. A more flexible approach is to use
the `getopt_long` library as shown in the example
[here](https://www.gnu.org/software/libc/manual/html_node/Getopt-Long-Option-Example.html).

## Questions for Thought
1. Can you connect the idea of command line arguments for a c++ project to the positional arguments we have seen in bash scripts (e.g., `$1`, `$2`, ..., `${@}`)?
2. $1 is equivalent to argv[i] when i equals what value?
